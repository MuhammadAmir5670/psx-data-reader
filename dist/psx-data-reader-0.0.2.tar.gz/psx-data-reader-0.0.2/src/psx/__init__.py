from psx.web import data_reader


__version__ = "1.0.0"

stocks = data_reader.stocks
tickers = data_reader.tickers