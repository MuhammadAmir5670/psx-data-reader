# psx-data-reader
A scraper for downloading Pakistan stock exchange's data into Python Pandas DataFrame.
